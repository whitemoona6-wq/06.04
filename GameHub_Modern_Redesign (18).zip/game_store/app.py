from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
import random
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'steam-like-secret-key-2024-change-in-prod'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ───────────────────────── DB ─────────────────────────

def get_db():
    conn = sqlite3.connect('game_store.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        display_name TEXT,
        bio TEXT DEFAULT '',
        avatar TEXT DEFAULT '',
        balance REAL DEFAULT 1000.0,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS games (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        short_description TEXT,
        price REAL NOT NULL,
        discount INTEGER DEFAULT 0,
        image_url TEXT,
        header_image TEXT,
        screenshots TEXT DEFAULT '',
        genre TEXT,
        developer TEXT,
        publisher TEXT,
        release_date TEXT,
        tags TEXT,
        rating REAL DEFAULT 0,
        reviews_count INTEGER DEFAULT 0,
        system_requirements TEXT,
        age_rating TEXT DEFAULT '12+',
        featured INTEGER DEFAULT 0
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS library (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        purchase_date TEXT DEFAULT CURRENT_TIMESTAMP,
        playtime INTEGER DEFAULT 0,
        favorite INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id),
        UNIQUE(user_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS wishlist (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        added_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id),
        UNIQUE(user_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id),
        UNIQUE(user_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        rating INTEGER CHECK(rating >= 1 AND rating <= 5),
        text TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS friends (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, friend_id INTEGER,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (friend_id) REFERENCES users(id),
        UNIQUE(user_id, friend_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT,
        details TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS news (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        body TEXT,
        image_url TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS gifts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_user INTEGER, to_user INTEGER, game_id INTEGER,
        message TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (from_user) REFERENCES users(id),
        FOREIGN KEY (to_user) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id)
    )''')


    c.execute('''CREATE TABLE IF NOT EXISTS achievements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        icon TEXT DEFAULT 'fa-trophy',
        points INTEGER DEFAULT 10
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS user_achievements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, achievement_id INTEGER,
        unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, achievement_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS promo_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        discount_percent INTEGER DEFAULT 10,
        max_uses INTEGER DEFAULT 100,
        used_count INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        expires_at TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        body TEXT,
        link TEXT DEFAULT '',
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS review_likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, review_id INTEGER,
        UNIQUE(user_id, review_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS purchase_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        price_paid REAL,
        promo_code TEXT DEFAULT '',
        purchased_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS collections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT UNIQUE,
        title TEXT,
        description TEXT,
        image_url TEXT DEFAULT ''
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS collection_games (
        collection_id INTEGER, game_id INTEGER,
        UNIQUE(collection_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS guides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_id INTEGER, user_id INTEGER,
        title TEXT, body TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        active INTEGER DEFAULT 1,
        started_at TEXT DEFAULT CURRENT_TIMESTAMP,
        expires_at TEXT
    )''')

    try:
        c.execute("ALTER TABLE users ADD COLUMN status TEXT DEFAULT 'online'")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE games ADD COLUMN trailer_url TEXT DEFAULT ''")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE games ADD COLUMN is_preorder INTEGER DEFAULT 0")
    except Exception:
        pass


    conn.commit()
    seed_games(conn)
    seed_extra(conn)
    seed_news(conn)
    localize_game_texts(conn)
    conn.commit()
    conn.close()


def localize_game_texts(conn):
    """Update game texts to Russian and assign each game a primary category."""
    # title -> (short_ru, description_ru, primary_category, full_genre_ru, tags_ru)
    data = {
        'Cyberpunk 2077': (
            'Ролевой боевик в мрачном Найт-Сити будущего.',
            'Станьте наёмником в тёмном будущем Найт-Сити — мегаполисе одержимости властью, гламуром и модификациями тела. Создайте своего персонажа, прокачивайте импланты и навыки, принимайте решения, которые меняют сюжет и судьбы окружающих. Исследуйте открытый мир районов города, выполняйте заказы, ввязывайтесь в бандитские разборки и раскройте заговор вокруг чипа, который меняет сознание. Масштабная история, яркие персонажи и атмосфера киберпанка.',
            'RPG',
            'RPG, Экшен, Открытый мир',
            'Киберпанк,RPG,Открытый мир'
        ),
        'Elden Ring': (
            'Эпическая action-RPG в открытом мире от FromSoftware.',
            'Отправляйтесь в Междуземье — разрушенное королевство, где правит хаос после раскола Кольца Элден. Создайте своего Погасшего, исследуйте огромный открытый мир, сражайтесь с боссами и раскрывайте тайны Золотого порядка. Свобода исследования, глубокий бой в духе Dark Souls и богатое лорное повествование.',
            'RPG',
            'RPG, Экшен, Открытый мир',
            'Souls-like,RPG,Открытый мир'
        ),
        'Red Dead Redemption 2': (
            'Эпическая история жизни на закате Дикого Запада.',
            'Америка, 1899 год. Артур Морган и банда Ван дер Линде вынуждены бежать после ограбления, пошедшего не по плану. Вас ждёт огромный детализированный мир, кинематографичный сюжет о чести, предательстве и выживании, охота, ограбления, покер и сотни второстепенных историй.',
            'Приключения',
            'Приключения, Экшен, Открытый мир',
            'Вестерн,Сюжет,Открытый мир'
        ),
        'Grand Theft Auto V': (
            'Трое преступников — один город хаоса.',
            'Лос-Сантос и округ Блэйн — огромный открытый мир, где переплетаются судьбы Майкла, Франклина и Тревора. Ограбления, погони, перестрелки и чёрный юмор Rockstar. Плюс GTA Online — живой мультиплеер с миссиями, бизнесом и гонками.',
            'Экшен',
            'Экшен, Открытый мир',
            'Экшен,Криминал,Мультиплеер'
        ),
        'The Witcher 3: Wild Hunt': (
            'Легендарная RPG о ведьмаке Геральте из Ривии.',
            'Геральт из Ривии ищет приёмную дочь Цири, пока Дикая Охота наступает на пятки. Огромный открытый мир, нелинейные квесты с тяжёлыми моральными выборами, охота на чудовищ и богатая вселенная Сапковского.',
            'RPG',
            'RPG, Приключения, Открытый мир',
            'Фэнтези,Сюжет,Открытый мир'
        ),
        'Hogwarts Legacy': (
            'Жизнь ученика в мире Гарри Поттера.',
            'Поступите в Хогвартс XIX века, освойте заклинания, зелья и полёты на метле, исследуйте замок и окрестности. Раскройте древнюю тайну, связанную с вашим даром, и определите, на чьей вы стороне.',
            'RPG',
            'RPG, Приключения, Экшен',
            'Магия,Открытый мир,Приключения'
        ),
        'Sekiro: Shadows Die Twice': (
            'Сюжетный action о синоби в Японии эпохи Сэнгоку.',
            'Станьте одноруким волком — синоби, связанным долгом защищать молодого лорда. Освойте уникальную боевую систему осанки: парирования, контрудары и смертельные приёмы. Исследуйте переплетённые локации и сражайтесь с боссами.',
            'Экшен',
            'Экшен, Приключения',
            'Синоби,Сложно,Япония'
        ),
        'Subnautica': (
            'Подводное выживание на чужой планете.',
            'Ваш корабль разбился у берегов океанической планеты. Ныряйте в глубины, собирайте ресурсы, стройте базы и подводные аппараты, изучайте фауну и раскрывайте тайну, скрытую на дне.',
            'Приключения',
            'Приключения, Симуляторы, Выживание',
            'Выживание,Подводный мир,Исследование'
        ),
        'Stardew Valley': (
            'Уютная фермерская RPG от ConcernedApe.',
            'Унаследуйте дедушкину ферму и начните новую жизнь в долине. Выращивайте культуры, разводите животных, дружите с жителями, исследуйте шахты и находите любовь.',
            'Симуляторы',
            'Симуляторы, RPG, Инди',
            'Ферма,Пиксель-арт,Уют'
        ),
        'Hades': (
            'Динамичный roguelike о побеге из Подземного мира.',
            'Загрей, сын Аида, снова и снова пытается вырваться из Подземного мира. Каждый забег — новая комбинация даров богов Олимпа, врагов и комнат. Блестящий бой, сильный сюжет и харизматичные персонажи.',
            'Инди',
            'Инди, Экшен, Roguelike',
            'Roguelike,Мифология,Инди'
        ),
        'Forza Horizon 5': (
            'Открытый гоночный фестиваль в Мексике.',
            'Сотни лицензированных автомобилей, потрясающие биомы Мексики и легендарный фестиваль Horizon. Свободные гонки, сезонные события, тюнинг и мультиплеер.',
            'Гонки',
            'Гонки, Симуляторы, Открытый мир',
            'Авто,Открытый мир,Фестиваль'
        ),
        'Phasmophobia': (
            'Кооперативный хоррор про охоту на призраков.',
            'В команде до четырёх игроков исследуйте локации, собирайте улики и определяйте тип призрака. Темнота, голоса и внезапные атаки создают настоящий страх.',
            'Хоррор',
            'Хоррор, Инди, Кооператив',
            'Кооп,Призраки,Страх'
        ),
        'XCOM 2': (
            'Тактическая стратегия о сопротивлении инопланетянам.',
            'Земля захвачена. Вы возглавляете сопротивление: управляете базой, нанимаете бойцов и ведёте пошаговые бои против оккупантов. Каждая потеря незаменима, каждая миссия — риск.',
            'Стратегии',
            'Стратегии, Тактика',
            'Пошаговая,Тактика,Sci-Fi'
        ),
        'Portal 2': (
            'Легендарный пазл с портальной пушкой.',
            'Решайте головоломки с помощью порталов, сопровождая сарказм GLaDOS. Одиночная кампания и кооператив на двух игроков с уникальными камерами.',
            'Приключения',
            'Приключения, Головоломка',
            'Пазл,Юмор,Кооп'
        ),
        'Football Manager 2024': (
            'Глубочайший футбольный менеджер.',
            'Возглавьте любой клуб мира: тактика, трансферы, молодёжка и психология раздевалки. База данных с тысячами реальных игроков и команд.',
            'Спортивные',
            'Спортивные, Симуляторы',
            'Футбол,Менеджер,Спорт'
        ),
        'RimWorld': (
            'Симулятор колонии на краю галактики.',
            'Трое выживших на чужой планете. Стройте базу, обрабатывайте поля, лечите раненых и переживайте истории, которые пишет ИИ-рассказчик.',
            'Стратегии',
            'Стратегии, Симуляторы, Инди',
            'Колония,Выживание,Инди'
        ),
        'Hacknet': (
            'Симулятор хакерства с интерфейсом терминала.',
            'Взламывайте системы, пишите скрипты, читайте почту и раскрывайте заговор через аутентичный интерфейс командной строки.',
            'Инди',
            'Инди, Симуляторы, Головоломка',
            'Хакер,Терминал,Киберпанк'
        ),
        'DiRT Rally 2.0': (
            'Хардкорный ралли-симулятор.',
            'Грязь, снег, гравий и непрощающая физика от Codemasters. Трассы по всему миру и управление, требующее точности.',
            'Гонки',
            'Гонки, Симуляторы, Спортивные',
            'Ралли,Симулятор,Сложно'
        ),
        'Hollow Knight': (
            'Атмосферная metroidvania в королевстве насекомых.',
            'Исследуйте Халлоунест — павшее королевство насекомых. Сражайтесь с боссами, открывайте способности и раскрывайте древнюю тайну.',
            'Инди',
            'Инди, Экшен, Приключения',
            'Metroidvania,Платформер,Инди'
        ),
        'Counter-Strike 2': (
            'Культовый тактический шутер на Source 2.',
            'Новая глава легендарной серии: обновлённая графика, физика дыма и тот же бескомпромиссный соревновательный геймплей. Бесплатно для всех.',
            'Экшен',
            'Экшен, Шутер, Бесплатные',
            'FPS,Киберспорт,Бесплатно'
        ),
        'Age of Empires II: DE': (
            'Классическая RTS в издании Definitive Edition.',
            'Стройте империи, командуйте цивилизациями и сражайтесь в 4K. Обновлённая графика, новые кампании и весь дух оригинальной стратегии.',
            'Стратегии',
            'Стратегии, RTS',
            'RTS,Средневековье,Стратегия'
        ),
        'The Elder Scrolls Online': (
            'MMORPG во вселенной The Elder Scrolls.',
            'Исследуйте Тамриэль вместе с тысячами игроков: Скайрим, Морровинд и другие провинции. Свободная прокачка, подземелья, PvP и сюжетные главы.',
            'RPG',
            'RPG, MMORPG, Фэнтези',
            'MMORPG,Фэнтези,TES'
        ),
    }
    c = conn.cursor()
    for title, (short, desc, primary, genre, tags) in data.items():
        c.execute(
            'UPDATE games SET short_description=?, description=?, genre=?, tags=? WHERE title=?',
            (short, desc, genre, tags, title)
        )
    conn.commit()



def seed_games(conn):
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM games')
    if c.fetchone()[0] > 0:
        return

    games = [{'title': 'Cyberpunk 2077', 'short_description': 'Action RPG in Night City.', 'description': 'Become a mercenary in the dark future of Night City. Customize your character and make choices that shape the story.', 'price': 2499, 'discount': 50, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/library_hero.jpg', 'genre': 'RPG, Action, Open World', 'developer': 'CD PROJEKT RED', 'publisher': 'CD PROJEKT RED', 'release_date': '2020-12-10', 'tags': 'Cyberpunk,RPG,Open World', 'rating': 4.5, 'reviews_count': 450000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '18+', 'featured': 1}, {'title': 'Elden Ring', 'short_description': 'Epic open-world action RPG by FromSoftware.', 'description': 'Explore the Lands Between, fight epic bosses and uncover the mystery of the Elden Ring.', 'price': 3999, 'discount': 30, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/library_hero.jpg', 'genre': 'Action, RPG, Open World', 'developer': 'FromSoftware', 'publisher': 'Bandai Namco', 'release_date': '2022-02-25', 'tags': 'Souls-like,RPG,Open World', 'rating': 4.9, 'reviews_count': 520000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 1}, {'title': 'Red Dead Redemption 2', 'short_description': 'Epic tale of life in America at the dawn of the modern age.', 'description': 'Arthur Morgan and the Van der Linde gang must fight to survive in a world that does not want them.', 'price': 2499, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/library_hero.jpg', 'genre': 'Action, Adventure, Open World', 'developer': 'Rockstar Games', 'publisher': 'Rockstar Games', 'release_date': '2019-12-05', 'tags': 'Western,Open World,Story', 'rating': 4.9, 'reviews_count': 480000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '18+', 'featured': 1}, {'title': 'Grand Theft Auto V', 'short_description': 'Three criminals, one city of chaos.', 'description': 'Los Santos underworld story plus GTA Online with endless content.', 'price': 1999, 'discount': 67, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/271590/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/271590/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/271590/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/271590/library_hero.jpg', 'genre': 'Action, Open World', 'developer': 'Rockstar North', 'publisher': 'Rockstar Games', 'release_date': '2015-04-14', 'tags': 'Open World,Crime,Multiplayer', 'rating': 4.7, 'reviews_count': 1200000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '18+', 'featured': 1}, {'title': 'The Witcher 3: Wild Hunt', 'short_description': 'Award-winning RPG about Geralt of Rivia.', 'description': 'Hunt monsters, make hard choices and explore a vast fantasy world.', 'price': 999, 'discount': 70, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/292030/library_hero.jpg', 'genre': 'RPG, Open World, Adventure', 'developer': 'CD PROJEKT RED', 'publisher': 'CD PROJEKT RED', 'release_date': '2015-05-19', 'tags': 'Fantasy,RPG,Story', 'rating': 4.9, 'reviews_count': 650000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '18+', 'featured': 0}, {'title': 'Hogwarts Legacy', 'short_description': 'Live the unwritten in the Harry Potter universe.', 'description': 'Attend Hogwarts, master spells and uncover ancient secrets.', 'price': 2999, 'discount': 40, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/990080/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/990080/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/990080/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/990080/library_hero.jpg', 'genre': 'Action, RPG, Adventure', 'developer': 'Avalanche Software', 'publisher': 'Warner Bros.', 'release_date': '2023-02-10', 'tags': 'Magic,RPG,Harry Potter', 'rating': 4.4, 'reviews_count': 180000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 1}, {'title': "Baldur's Gate 3", 'short_description': 'CRPG of the year from Larian Studios.', 'description': 'Gather your party, embrace freedom of choice and save the Forgotten Realms.', 'price': 3499, 'discount': 20, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/library_hero.jpg', 'genre': 'RPG, Turn-based, Adventure', 'developer': 'Larian Studios', 'publisher': 'Larian Studios', 'release_date': '2023-08-03', 'tags': 'D&D,RPG,Co-op', 'rating': 4.9, 'reviews_count': 420000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '18+', 'featured': 1}, {'title': 'Sekiro: Shadows Die Twice', 'short_description': 'Shinobi action in Sengoku Japan.', 'description': 'Master the posture combat system and carve your own path of vengeance.', 'price': 2199, 'discount': 35, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/814380/library_hero.jpg', 'genre': 'Action, Adventure, Stealth', 'developer': 'FromSoftware', 'publisher': 'Activision', 'release_date': '2019-03-22', 'tags': 'Stealth,Hard,Japan', 'rating': 4.8, 'reviews_count': 160000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 0}, {'title': 'Subnautica', 'short_description': 'Underwater survival adventure.', 'description': 'Dive into an alien ocean, build bases and uncover the mystery of a crashed ship.', 'price': 1299, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/264710/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/264710/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/264710/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/264710/library_hero.jpg', 'genre': 'Adventure, Survival, Simulation', 'developer': 'Unknown Worlds', 'publisher': 'Unknown Worlds', 'release_date': '2018-01-23', 'tags': 'Ocean,Survival,Exploration', 'rating': 4.7, 'reviews_count': 220000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 0}, {'title': 'Stardew Valley', 'short_description': 'Charming farming RPG by ConcernedApe.', 'description': 'Grow crops, raise animals, befriend villagers and explore the mines.', 'price': 799, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/413150/library_hero.jpg', 'genre': 'Simulation, RPG, Indie', 'developer': 'ConcernedApe', 'publisher': 'ConcernedApe', 'release_date': '2016-02-26', 'tags': 'Farm,Cozy,Indie', 'rating': 4.9, 'reviews_count': 480000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '6+', 'featured': 1}, {'title': 'Hades', 'short_description': 'Roguelike escape from the Underworld.', 'description': 'Battle out of the House of Hades in this award-winning Supergiant title.', 'price': 999, 'discount': 25, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1145360/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1145360/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1145360/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1145360/library_hero.jpg', 'genre': 'Action, Roguelike, Indie', 'developer': 'Supergiant Games', 'publisher': 'Supergiant Games', 'release_date': '2020-09-17', 'tags': 'Roguelike,Indie,Mythology', 'rating': 4.9, 'reviews_count': 200000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 0}, {'title': "No Man's Sky", 'short_description': 'Infinite procedurally generated universe.', 'description': 'Explore planets, build bases, trade and survive across the galaxy.', 'price': 1599, 'discount': 15, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/275850/library_hero.jpg', 'genre': 'Adventure, Simulation, Open World', 'developer': 'Hello Games', 'publisher': 'Hello Games', 'release_date': '2016-08-12', 'tags': 'Space,Exploration,Survival', 'rating': 4.4, 'reviews_count': 210000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 0}, {'title': 'Forza Horizon 5', 'short_description': 'Open-world racing festival in Mexico.', 'description': 'Hundreds of cars, stunning landscapes and the Horizon Festival.', 'price': 2799, 'discount': 10, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/library_hero.jpg', 'genre': 'Racing, Simulation, Open World', 'developer': 'Playground Games', 'publisher': 'Xbox Game Studios', 'release_date': '2021-11-09', 'tags': 'Racing,Cars,Open World', 'rating': 4.6, 'reviews_count': 140000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '6+', 'featured': 0}, {'title': 'Phasmophobia', 'short_description': 'Co-op ghost hunting horror.', 'description': 'Use equipment to identify ghosts with up to 4 players. Scary and fun.', 'price': 999, 'discount': 50, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/739630/library_hero.jpg', 'genre': 'Horror, Co-op, Indie', 'developer': 'Kinetic Games', 'publisher': 'Kinetic Games', 'release_date': '2020-09-18', 'tags': 'Horror,Co-op,Ghosts', 'rating': 4.6, 'reviews_count': 380000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 0}, {'title': 'XCOM 2', 'short_description': 'Tactical strategy against alien occupation.', 'description': 'Lead the resistance, manage your base and fight for Earth turn by turn.', 'price': 1699, 'discount': 25, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/268500/library_hero.jpg', 'genre': 'Strategy, Tactical, Turn-based', 'developer': 'Firaxis Games', 'publisher': '2K', 'release_date': '2016-02-05', 'tags': 'Tactics,Strategy,XCOM', 'rating': 4.6, 'reviews_count': 90000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 0}, {'title': 'Portal 2', 'short_description': 'Legendary portal puzzle adventure.', 'description': 'Co-op chambers, dark humor and the most iconic gun in gaming.', 'price': 699, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/620/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/620/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/620/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/620/library_hero.jpg', 'genre': 'Puzzle, Adventure', 'developer': 'Valve', 'publisher': 'Valve', 'release_date': '2011-04-19', 'tags': 'Puzzle,Co-op,Valve', 'rating': 4.9, 'reviews_count': 280000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 0}, {'title': 'Football Manager 2024', 'short_description': 'Deepest football management simulation.', 'description': 'Manage any club, tactics, transfers and youth development.', 'price': 1999, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/library_hero.jpg', 'genre': 'Sports, Simulation, Management', 'developer': 'Sports Interactive', 'publisher': 'SEGA', 'release_date': '2023-11-06', 'tags': 'Football,Manager,Sports', 'rating': 4.6, 'reviews_count': 25000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '6+', 'featured': 0}, {'title': 'RimWorld', 'short_description': 'Colony sim on the rim of the galaxy.', 'description': 'Build, survive and experience AI-driven stories of your colonists.', 'price': 1499, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/294100/library_hero.jpg', 'genre': 'Simulation, Strategy, Indie', 'developer': 'Ludeon Studios', 'publisher': 'Ludeon Studios', 'release_date': '2018-10-17', 'tags': 'Colony,Survival,Indie', 'rating': 4.9, 'reviews_count': 150000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 0}, {'title': 'Hacknet', 'short_description': 'Hacking simulator with terminal UI.', 'description': 'Break into systems, write scripts and uncover a conspiracy.', 'price': 499, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/365450/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/365450/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/365450/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/365450/library_hero.jpg', 'genre': 'Simulation, Indie, Puzzle', 'developer': 'Team Fractal Alligator', 'publisher': 'Fellow Traveller', 'release_date': '2015-08-12', 'tags': 'Hacker,Indie,Cyberpunk', 'rating': 4.5, 'reviews_count': 25000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 0}, {'title': 'DiRT Rally 2.0', 'short_description': 'Hardcore rally simulation.', 'description': 'Mud, snow, gravel and unforgiving physics from Codemasters.', 'price': 1799, 'discount': 10, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/library_hero.jpg', 'genre': 'Racing, Simulation, Sports', 'developer': 'Codemasters', 'publisher': 'EA', 'release_date': '2019-02-26', 'tags': 'Rally,Racing,Simulation', 'rating': 4.4, 'reviews_count': 30000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '6+', 'featured': 0}, {'title': 'Hollow Knight', 'short_description': 'Atmospheric metroidvania in a bug kingdom.', 'description': 'Explore Hallownest, battle bosses and uncover an ancient mystery.', 'price': 599, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/367520/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/367520/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/367520/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/367520/library_hero.jpg', 'genre': 'Action, Adventure, Indie', 'developer': 'Team Cherry', 'publisher': 'Team Cherry', 'release_date': '2017-02-24', 'tags': 'Metroidvania,Indie,Platformer', 'rating': 4.9, 'reviews_count': 280000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 1}, {'title': 'Counter-Strike 2', 'short_description': 'Tactical FPS icon, rebuilt on Source 2.', 'description': 'Competitive gunplay, new smokes and the same legendary modes.', 'price': 0, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/730/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/730/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/730/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/730/library_hero.jpg', 'genre': 'Shooter, FPS, Free-to-Play', 'developer': 'Valve', 'publisher': 'Valve', 'release_date': '2023-09-27', 'tags': 'FPS,Esports,Free', 'rating': 4.0, 'reviews_count': 900000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 1}, {'title': 'Age of Empires II: DE', 'short_description': 'Classic RTS in definitive edition.', 'description': 'Build empires, command civilizations and conquer in 4K.', 'price': 1899, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/813780/library_hero.jpg', 'genre': 'Strategy, RTS', 'developer': 'Forgotten Empires', 'publisher': 'Xbox Game Studios', 'release_date': '2019-11-14', 'tags': 'RTS,Strategy,Medieval', 'rating': 4.7, 'reviews_count': 80000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '12+', 'featured': 0}, {'title': 'The Elder Scrolls Online', 'short_description': 'MMORPG set in Tamriel.', 'description': 'Explore Skyrim and Morrowind with thousands of other players.', 'price': 0, 'discount': 0, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/306130/library_hero.jpg', 'genre': 'MMORPG, Fantasy, RPG', 'developer': 'ZeniMax Online', 'publisher': 'Bethesda', 'release_date': '2014-04-04', 'tags': 'MMORPG,Fantasy,TES', 'rating': 4.2, 'reviews_count': 120000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 50 GB', 'age_rating': '16+', 'featured': 0},
    {'title': "Baldur's Gate 3", 'short_description': 'CRPG of the year from Larian Studios.', 'description': 'Gather your party, embrace freedom of choice and save the Forgotten Realms in this D&D CRPG.', 'price': 3499, 'discount': 20, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/library_hero.jpg', 'genre': 'RPG, Turn-based, Adventure', 'developer': 'Larian Studios', 'publisher': 'Larian Studios', 'release_date': '2023-08-03', 'tags': 'D&D,RPG,Co-op', 'rating': 4.9, 'reviews_count': 420000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 150 GB', 'age_rating': '18+', 'featured': 1},
    {'title': "No Man's Sky", 'short_description': 'Infinite procedurally generated universe.', 'description': 'Explore planets, build bases, trade and survive across a vast galaxy.', 'price': 1599, 'discount': 15, 'image_url': 'https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg', 'header_image': 'https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg', 'screenshots': 'https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/275850/library_hero.jpg', 'genre': 'Adventure, Simulation, Open World', 'developer': 'Hello Games', 'publisher': 'Hello Games', 'release_date': '2016-08-12', 'tags': 'Space,Exploration,Survival', 'rating': 4.4, 'reviews_count': 210000, 'system_requirements': 'OS: Windows 10 | CPU: Intel i5 | RAM: 8 GB | GPU: GTX 1060 | Storage: 15 GB', 'age_rating': '12+', 'featured': 0}
]

    for g in games:
        c.execute("""INSERT INTO games (title, description, short_description, price, discount,
                     image_url, header_image, screenshots, genre, developer, publisher,
                     release_date, tags, rating, reviews_count, system_requirements, age_rating, featured)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (g['title'], g['description'], g['short_description'], g['price'], g['discount'],
                   g['image_url'], g['header_image'], g['screenshots'], g['genre'],
                   g['developer'], g['publisher'], g['release_date'], g['tags'],
                   g['rating'], g['reviews_count'], g['system_requirements'],
                   g['age_rating'], g['featured']))
    conn.commit()


def seed_news(conn):
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM news')
    if c.fetchone()[0] > 0:
        return
    news_items = [
        ('Летняя распродажа началась!', 'Скидки до 50% на сотни игр. Не пропустите лучшие предложения сезона. Акция действует до конца месяца.', 'https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg'),
        ('Cyberpunk 2077 — обновление 2.0', 'Масштабный патч добавляет новый район города, систему транспорта и улучшенный ИИ. Бесплатно для всех владельцев.', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg'),
        ('Counter-Strike 2 — новый сезон', 'Сезон «Железный шторм» уже доступен. Новый боевой пропуск, 3 меха и карта «Заброшенный завод».', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1237970/header.jpg'),
        ('GameHub — что нового', 'Добавлены друзья, подарки, новости, скриншоты игр и система избранного в библиотеке. Спасибо за отзывы!', 'https://cdn.cloudflare.steamstatic.com/steam/apps/730/header.jpg'),
    ]
    for t, b, img in news_items:
        c.execute('INSERT INTO news (title, body, image_url) VALUES (?,?,?)', (t, b, img))
    conn.commit()


def seed_extra(conn):
    c = conn.cursor()
    # Achievements
    c.execute('SELECT COUNT(*) FROM achievements')
    if c.fetchone()[0] == 0:
        ach = [
            ('first_purchase', 'Первая покупка', 'Купите свою первую игру', 'fa-shopping-bag', 20),
            ('collector_5', 'Коллекционер', 'Соберите 5 игр в библиотеке', 'fa-book', 30),
            ('collector_10', 'Библиотека мечты', '10 игр в библиотеке', 'fa-book-open', 50),
            ('reviewer', 'Критик', 'Оставьте первый отзыв', 'fa-star', 15),
            ('social', 'Дружелюбный', 'Добавьте первого друга', 'fa-user-friends', 15),
            ('generous', 'Щедрый', 'Подарите игру другу', 'fa-gift', 25),
            ('wishlist', 'Мечтатель', 'Добавьте игру в желаемое', 'fa-heart', 10),
            ('gamer', 'Геймер', 'Наберите 60 минут игрового времени', 'fa-gamepad', 20),
            ('rich', 'Толстосум', 'Пополните баланс', 'fa-coins', 10),
            ('subscriber', 'Подписчик', 'Оформите GameHub Plus', 'fa-crown', 40),
        ]
        for a in ach:
            c.execute('INSERT INTO achievements (code, title, description, icon, points) VALUES (?,?,?,?,?)', a)

    # Promo codes
    c.execute('SELECT COUNT(*) FROM promo_codes')
    if c.fetchone()[0] == 0:
        for code, pct in [('GAMEHUB10', 10), ('STEAM20', 20), ('SALE30', 30), ('WELCOME15', 15)]:
            c.execute('INSERT INTO promo_codes (code, discount_percent, max_uses) VALUES (?,?,?)', (code, pct, 1000))

    # Collections
    c.execute('SELECT COUNT(*) FROM collections')
    if c.fetchone()[0] == 0:
        cols = [
            ('indie-hits', 'Инди-хиты', 'Лучшие независимые игры', ''),
            ('coop', 'Кооператив', 'Играйте вместе с друзьями', ''),
            ('bestsellers', 'Бестселлеры', 'Самые популярные игры', ''),
            ('free-to-play', 'Бесплатные', 'Играйте бесплатно', ''),
        ]
        for slug, title, desc, img in cols:
            c.execute('INSERT INTO collections (slug, title, description, image_url) VALUES (?,?,?,?)', (slug, title, desc, img))
        # link some games
        games = c.execute('SELECT id, price, tags, genre FROM games').fetchall()
        col_ids = {r[0]: r[1] for r in c.execute('SELECT slug, id FROM collections').fetchall()}
        for g in games:
            gid, price, tags, genre = g[0], g[1], (g[2] or ''), (g[3] or '')
            if price == 0 and 'free-to-play' in col_ids:
                c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['free-to-play'], gid))
            if 'Инди' in tags or 'Indie' in genre:
                if 'indie-hits' in col_ids:
                    c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['indie-hits'], gid))
            if 'Кооп' in tags or 'Co-op' in genre or 'Мультиплеер' in tags:
                if 'coop' in col_ids:
                    c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['coop'], gid))
            if 'bestsellers' in col_ids:
                c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['bestsellers'], gid))

    # Trailers for some games
    trailers = {
        'Cyberpunk 2077': 'https://www.youtube.com/embed/qIcTM8WXFjk',
        'Elden Ring': 'https://www.youtube.com/embed/K_03kFqWgP0',
        'Red Dead Redemption 2': 'https://www.youtube.com/embed/eaW0tYpxyp0',
        'Grand Theft Auto V': 'https://www.youtube.com/embed/QkkoHAzjnUs',
        'Hogwarts Legacy': 'https://www.youtube.com/embed/BtyukzO91Ts',
        'Subnautica': 'https://www.youtube.com/embed/Rz2SNm8VQu0',
    }
    for title, url in trailers.items():
        c.execute('UPDATE games SET trailer_url=? WHERE title=?', (url, title))

    # Sample guides
    c.execute('SELECT COUNT(*) FROM guides')
    if c.fetchone()[0] == 0:
        g = c.execute('SELECT id FROM games LIMIT 3').fetchall()
        if g:
            c.execute('INSERT INTO guides (game_id, user_id, title, body) VALUES (?,?,?,?)',
                      (g[0][0], 1, 'Гайд для новичков', 'Начните с сюжетной кампании. Не тратьте ресурсы впустую. Изучите карту и сохраняйтесь часто.'))
            if len(g) > 1:
                c.execute('INSERT INTO guides (game_id, user_id, title, body) VALUES (?,?,?,?)',
                          (g[1][0], 1, 'Оптимальная сборка', 'Для максимального DPS качайте ветку силы. Экипируйте артефакты с бонусом к криту.'))

    conn.commit()


def notify(user_id, title, body, link=''):
    try:
        conn = get_db()
        conn.execute('INSERT INTO notifications (user_id, title, body, link) VALUES (?,?,?,?)',
                     (user_id, title, body, link))
        conn.commit()
        conn.close()
    except Exception:
        pass


def unlock_achievement(user_id, code):
    try:
        conn = get_db()
        ach = conn.execute('SELECT id, title FROM achievements WHERE code=?', (code,)).fetchone()
        if not ach:
            conn.close()
            return
        try:
            conn.execute('INSERT INTO user_achievements (user_id, achievement_id) VALUES (?,?)',
                         (user_id, ach['id']))
            conn.commit()
            notify(user_id, 'Достижение разблокировано!', ach['title'], '/achievements')
        except Exception:
            pass
        conn.close()
    except Exception:
        pass


def check_achievements(user_id):
    conn = get_db()
    lib_count = conn.execute('SELECT COUNT(*) FROM library WHERE user_id=?', (user_id,)).fetchone()[0]
    rev_count = conn.execute('SELECT COUNT(*) FROM reviews WHERE user_id=?', (user_id,)).fetchone()[0]
    playtime = conn.execute('SELECT COALESCE(SUM(playtime),0) FROM library WHERE user_id=?', (user_id,)).fetchone()[0]
    conn.close()
    if lib_count >= 1:
        unlock_achievement(user_id, 'first_purchase')
    if lib_count >= 5:
        unlock_achievement(user_id, 'collector_5')
    if lib_count >= 10:
        unlock_achievement(user_id, 'collector_10')
    if rev_count >= 1:
        unlock_achievement(user_id, 'reviewer')
    if playtime >= 60:
        unlock_achievement(user_id, 'gamer')


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if not user or not user['is_admin']:
            flash('Доступ только для администратора', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated


def log_activity(user_id, action, details=''):
    try:
        conn = get_db()
        conn.execute('INSERT INTO activity (user_id, action, details) VALUES (?,?,?)',
                     (user_id, action, details))
        conn.commit()
        conn.close()
    except Exception:
        pass

# ───────────────────────── helpers ─────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Войдите в аккаунт, чтобы продолжить', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_current_user():
    if 'user_id' not in session:
        return None
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    return user

def get_final_price(game):
    if game['discount'] > 0:
        return round(game['price'] * (1 - game['discount'] / 100), 2)
    return game['price']

def track_recent(game_id):
    recent = session.get('recent', [])
    if game_id in recent:
        recent.remove(game_id)
    recent.insert(0, game_id)
    session['recent'] = recent[:10]

# ───────────────────────── routes ─────────────────────────

@app.route('/')
def index():
    conn = get_db()
    featured = conn.execute('SELECT * FROM games WHERE featured = 1 ORDER BY rating DESC LIMIT 8').fetchall()
    if not featured:
        featured = conn.execute('SELECT * FROM games ORDER BY rating DESC LIMIT 6').fetchall()
    specials = conn.execute('SELECT * FROM games WHERE discount > 0 ORDER BY discount DESC LIMIT 6').fetchall()
    new_releases = conn.execute('SELECT * FROM games ORDER BY release_date DESC LIMIT 6').fetchall()
    free = conn.execute('SELECT * FROM games WHERE price = 0').fetchall()
    top_rated = conn.execute('SELECT * FROM games ORDER BY rating DESC LIMIT 4').fetchall()
    news = conn.execute('SELECT * FROM news ORDER BY created_at DESC LIMIT 3').fetchall()
    conn.close()
    user = get_current_user()
    return render_template('index.html', featured=featured, specials=specials,
                           new_releases=new_releases, free=free, top_rated=top_rated,
                           news=news, user=user, get_final_price=get_final_price)

@app.route('/store')
def store():
    conn = get_db()
    query = request.args.get('q', '').strip()
    genre = request.args.get('genre', '')
    sort = request.args.get('sort', 'rating')
    max_price = request.args.get('max_price', type=float)
    only_discount = request.args.get('discount') == '1'
    free_only = request.args.get('free') == '1'

    sql = 'SELECT * FROM games WHERE 1=1'
    params = []
    if query:
        sql += ' AND (title LIKE ? OR tags LIKE ? OR developer LIKE ? OR genre LIKE ?)'
        params.extend([f'%{query}%'] * 4)
    if genre:
        sql += ' AND genre LIKE ?'
        params.append(f'%{genre}%')
    if max_price is not None:
        sql += ' AND price <= ?'
        params.append(max_price)
    if only_discount:
        sql += ' AND discount > 0'
    if free_only:
        sql += ' AND price = 0'

    if sort == 'price_asc':
        sql += ' ORDER BY CASE WHEN discount > 0 THEN price*(1-discount/100.0) ELSE price END ASC'
    elif sort == 'price_desc':
        sql += ' ORDER BY CASE WHEN discount > 0 THEN price*(1-discount/100.0) ELSE price END DESC'
    elif sort == 'name':
        sql += ' ORDER BY title ASC'
    elif sort == 'discount':
        sql += ' ORDER BY discount DESC'
    elif sort == 'date':
        sql += ' ORDER BY release_date DESC'
    else:
        sql += ' ORDER BY rating DESC'

    games = conn.execute(sql, params).fetchall()
    all_games = conn.execute('SELECT genre FROM games').fetchall()
    genres = set()
    for g in all_games:
        for part in (g['genre'] or '').split(','):
            part = part.strip()
            if part:
                genres.add(part)
    # Primary categories for grouping (first genre tag)
    category_order = ['Экшен', 'Приключения', 'RPG', 'Симуляторы', 'Стратегии', 'Гонки', 'Спортивные', 'Инди', 'Хоррор', 'Шутер', 'Бесплатные']
    grouped = {}
    for g in games:
        primary = (g['genre'] or 'Другое').split(',')[0].strip() or 'Другое'
        grouped.setdefault(primary, []).append(g)
    # ordered list of (category, games)
    ordered_groups = []
    seen = set()
    for cat in category_order:
        if cat in grouped:
            ordered_groups.append((cat, grouped[cat]))
            seen.add(cat)
    for cat, glist in sorted(grouped.items()):
        if cat not in seen:
            ordered_groups.append((cat, glist))
    conn.close()
    user = get_current_user()
    return render_template('store.html', games=games, user=user, query=query,
                           genre=genre, sort=sort, genres=sorted(genres),
                           max_price=max_price, only_discount=only_discount,
                           free_only=free_only, get_final_price=get_final_price,
                           ordered_groups=ordered_groups)

@app.route('/game/<int:game_id>')
def game_detail(game_id):
    conn = get_db()
    game = conn.execute('SELECT * FROM games WHERE id = ?', (game_id,)).fetchone()
    if not game:
        flash('Игра не найдена', 'error')
        return redirect(url_for('store'))
    track_recent(game_id)

    reviews = conn.execute('''SELECT r.*, u.username, u.display_name, u.avatar
                              FROM reviews r JOIN users u ON r.user_id = u.id
                              WHERE r.game_id = ? ORDER BY r.created_at DESC LIMIT 30''',
                           (game_id,)).fetchall()

    in_library = in_wishlist = in_cart = False
    user_review = None
    playtime = 0
    user = get_current_user()
    if user:
        lib = conn.execute('SELECT playtime FROM library WHERE user_id = ? AND game_id = ?',
                           (user['id'], game_id)).fetchone()
        in_library = lib is not None
        if lib:
            playtime = lib['playtime']
        in_wishlist = conn.execute('SELECT 1 FROM wishlist WHERE user_id = ? AND game_id = ?',
                                   (user['id'], game_id)).fetchone() is not None
        in_cart = conn.execute('SELECT 1 FROM cart WHERE user_id = ? AND game_id = ?',
                               (user['id'], game_id)).fetchone() is not None
        user_review = conn.execute('SELECT * FROM reviews WHERE user_id = ? AND game_id = ?',
                                   (user['id'], game_id)).fetchone()

    similar = conn.execute('''SELECT * FROM games WHERE id != ? AND
                              (genre LIKE ? OR tags LIKE ?) LIMIT 4''',
                           (game_id, f"%{game['genre'].split(',')[0].strip()}%",
                            f"%{game['tags'].split(',')[0].strip()}%")).fetchall()

    screenshots = [s.strip() for s in (game['screenshots'] or '').split(',') if s.strip()]
    conn.close()
    return render_template('game_detail.html', game=game, reviews=reviews, user=user,
                           in_library=in_library, in_wishlist=in_wishlist, in_cart=in_cart,
                           user_review=user_review, similar=similar, screenshots=screenshots,
                           playtime=playtime, get_final_price=get_final_price)

@app.route('/news')
def news_list():
    conn = get_db()
    items = conn.execute('SELECT * FROM news ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('news.html', news=items, user=get_current_user())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        if not username or not email or not password:
            flash('Заполните все поля', 'error')
            return render_template('register.html')
        if password != confirm:
            flash('Пароли не совпадают', 'error')
            return render_template('register.html')
        if len(password) < 6:
            flash('Пароль должен быть не менее 6 символов', 'error')
            return render_template('register.html')
        conn = get_db()
        try:
            hashed = generate_password_hash(password)
            c = conn.cursor()
            is_adm = 1 if username.lower() == 'admin' else 0
            c.execute('INSERT INTO users (username, email, password, display_name, is_admin) VALUES (?,?,?,?,?)',
                      (username, email, hashed, username, is_adm))
            conn.commit()
            user_id = c.lastrowid
            session['user_id'] = user_id
            session['username'] = username
            log_activity(user_id, 'register', 'Регистрация в GameHub')
            flash(f'Добро пожаловать, {username}! На ваш счёт зачислено 1000 ₽', 'success')
            return redirect(url_for('index'))
        except sqlite3.IntegrityError:
            flash('Имя пользователя или email уже заняты', 'error')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? OR email = ?',
                            (username, username)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            log_activity(user['id'], 'login', 'Вход в аккаунт')
            flash(f'С возвращением, {user["display_name"] or user["username"]}!', 'success')
            return redirect(url_for('index'))
        flash('Неверное имя пользователя или пароль', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из аккаунта', 'info')
    return redirect(url_for('index'))

@app.route('/profile')
@login_required
def profile():
    user = get_current_user()
    conn = get_db()
    library = conn.execute('''SELECT g.*, l.purchase_date, l.playtime, l.favorite
                              FROM library l JOIN games g ON l.game_id = g.id
                              WHERE l.user_id = ? ORDER BY l.favorite DESC, l.purchase_date DESC''',
                           (user['id'],)).fetchall()
    wishlist = conn.execute('''SELECT g.*, w.added_at FROM wishlist w
                               JOIN games g ON w.game_id = g.id WHERE w.user_id = ?
                               ORDER BY w.added_at DESC''', (user['id'],)).fetchall()
    reviews = conn.execute('''SELECT r.*, g.title, g.image_url FROM reviews r
                              JOIN games g ON r.game_id = g.id WHERE r.user_id = ?
                              ORDER BY r.created_at DESC''', (user['id'],)).fetchall()
    activities = conn.execute('''SELECT * FROM activity WHERE user_id = ?
                                 ORDER BY created_at DESC LIMIT 15''', (user['id'],)).fetchall()
    # friends
    friends = conn.execute('''SELECT u.id, u.username, u.display_name, u.avatar, f.status
                              FROM friends f JOIN users u ON
                              (CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END) = u.id
                              WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status = 'accepted' ''',
                           (user['id'], user['id'], user['id'])).fetchall()
    pending = conn.execute('''SELECT f.id as req_id, u.id, u.username, u.display_name, u.avatar
                              FROM friends f JOIN users u ON f.user_id = u.id
                              WHERE f.friend_id = ? AND f.status = 'pending' ''',
                           (user['id'],)).fetchall()
    gifts = conn.execute('''SELECT g.*, games.title, games.image_url, u.username as from_name
                            FROM gifts g JOIN games ON g.game_id = games.id
                            JOIN users u ON g.from_user = u.id
                            WHERE g.to_user = ? AND g.status = 'pending' ''',
                         (user['id'],)).fetchall()
    conn.close()
    return render_template('profile.html', user=user, library=library, wishlist=wishlist,
                           reviews=reviews, activities=activities, friends=friends,
                           pending=pending, gifts=gifts, get_final_price=get_final_price)

@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    user = get_current_user()
    if request.method == 'POST':
        display_name = request.form.get('display_name', '').strip()
        bio = request.form.get('bio', '').strip()
        conn = get_db()
        avatar_path = user['avatar']
        if 'avatar' in request.files:
            file = request.files['avatar']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"user_{user['id']}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                avatar_path = f'/static/uploads/{filename}'
        avatar_url = request.form.get('avatar_url', '').strip()
        if avatar_url and avatar_url.startswith('http'):
            avatar_path = avatar_url
        conn.execute('UPDATE users SET display_name=?, bio=?, avatar=? WHERE id=?',
                     (display_name or user['username'], bio, avatar_path, user['id']))
        conn.commit()
        conn.close()
        log_activity(user['id'], 'profile_edit', 'Обновлён профиль')
        flash('Профиль обновлён!', 'success')
        return redirect(url_for('profile'))
    return render_template('edit_profile.html', user=user)

@app.route('/profile/password', methods=['GET', 'POST'])
@login_required
def change_password():
    user = get_current_user()
    if request.method == 'POST':
        old = request.form.get('old_password', '')
        new = request.form.get('new_password', '')
        confirm = request.form.get('confirm', '')
        if not check_password_hash(user['password'], old):
            flash('Неверный текущий пароль', 'error')
        elif new != confirm:
            flash('Новые пароли не совпадают', 'error')
        elif len(new) < 6:
            flash('Пароль должен быть не менее 6 символов', 'error')
        else:
            conn = get_db()
            conn.execute('UPDATE users SET password=? WHERE id=?',
                         (generate_password_hash(new), user['id']))
            conn.commit()
            conn.close()
            flash('Пароль изменён', 'success')
            return redirect(url_for('profile'))
    return render_template('change_password.html', user=user)

@app.route('/cart')
@login_required
def cart():
    user = get_current_user()
    conn = get_db()
    items = conn.execute('''SELECT g.*, c.id as cart_id FROM cart c
                            JOIN games g ON c.game_id = g.id WHERE c.user_id = ?''',
                         (user['id'],)).fetchall()
    conn.close()
    total = sum(get_final_price(item) for item in items)
    promo_discount = session.get('promo_discount', 0)
    promo_code = session.get('promo_code', '')
    if promo_discount:
        total = round(total * (1 - promo_discount / 100), 2)
    return render_template('cart.html', items=items, total=total, user=user,
                           get_final_price=get_final_price, promo_code=promo_code,
                           promo_discount=promo_discount)

@app.route('/cart/add/<int:game_id>')
@login_required
def add_to_cart(game_id):
    user = get_current_user()
    conn = get_db()
    if conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                    (user['id'], game_id)).fetchone():
        flash('Эта игра уже у вас в библиотеке', 'info')
        conn.close()
        return redirect(url_for('game_detail', game_id=game_id))
    try:
        conn.execute('INSERT INTO cart (user_id, game_id) VALUES (?,?)', (user['id'], game_id))
        conn.commit()
        flash('Игра добавлена в корзину', 'success')
    except sqlite3.IntegrityError:
        flash('Игра уже в корзине', 'info')
    conn.close()
    return redirect(request.referrer or url_for('store'))

@app.route('/cart/remove/<int:game_id>')
@login_required
def remove_from_cart(game_id):
    conn = get_db()
    conn.execute('DELETE FROM cart WHERE user_id=? AND game_id=?', (session['user_id'], game_id))
    conn.commit()
    conn.close()
    flash('Игра удалена из корзины', 'info')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    user = get_current_user()
    conn = get_db()
    items = conn.execute('''SELECT g.* FROM cart c JOIN games g ON c.game_id = g.id
                            WHERE c.user_id = ?''', (user['id'],)).fetchall()
    if not items:
        flash('Корзина пуста', 'warning')
        conn.close()
        return redirect(url_for('cart'))
    total = sum(get_final_price(item) for item in items)
    promo_discount = session.get('promo_discount', 0)
    if promo_discount:
        total = round(total * (1 - promo_discount / 100), 2)
    if user['balance'] < total:
        flash(f'Недостаточно средств. Нужно {total:.0f} ₽, у вас {user["balance"]:.0f} ₽', 'error')
        conn.close()
        return redirect(url_for('cart'))
    titles = []
    for item in items:
        conn.execute('INSERT OR IGNORE INTO library (user_id, game_id) VALUES (?,?)',
                     (user['id'], item['id']))
        conn.execute('DELETE FROM wishlist WHERE user_id=? AND game_id=?', (user['id'], item['id']))
        titles.append(item['title'])
    conn.execute('UPDATE users SET balance = balance - ? WHERE id = ?', (total, user['id']))
    conn.execute('DELETE FROM cart WHERE user_id = ?', (user['id'],))
    conn.commit()
    conn.close()
    log_activity(user['id'], 'purchase', f'Куплено: {", ".join(titles)} за {total:.0f} ₽')
    flash(f'Покупка успешна! Списано {total:.0f} ₽. Игры добавлены в библиотеку.', 'success')
    return redirect(url_for('profile'))

@app.route('/wishlist/add/<int:game_id>')
@login_required
def add_to_wishlist(game_id):
    user = get_current_user()
    conn = get_db()
    if conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                    (user['id'], game_id)).fetchone():
        flash('Игра уже в библиотеке', 'info')
        conn.close()
        return redirect(url_for('game_detail', game_id=game_id))
    try:
        conn.execute('INSERT INTO wishlist (user_id, game_id) VALUES (?,?)', (user['id'], game_id))
        conn.commit()
        flash('Добавлено в список желаемого', 'success')
    except sqlite3.IntegrityError:
        flash('Уже в списке желаемого', 'info')
    conn.close()
    return redirect(request.referrer or url_for('game_detail', game_id=game_id))

@app.route('/wishlist/remove/<int:game_id>')
@login_required
def remove_from_wishlist(game_id):
    conn = get_db()
    conn.execute('DELETE FROM wishlist WHERE user_id=? AND game_id=?', (session['user_id'], game_id))
    conn.commit()
    conn.close()
    flash('Удалено из списка желаемого', 'info')
    return redirect(request.referrer or url_for('profile'))

@app.route('/review/<int:game_id>', methods=['POST'])
@login_required
def add_review(game_id):
    user = get_current_user()
    rating = request.form.get('rating', type=int)
    text = request.form.get('text', '').strip()
    if not rating or rating < 1 or rating > 5:
        flash('Выберите оценку от 1 до 5', 'error')
        return redirect(url_for('game_detail', game_id=game_id))
    conn = get_db()
    if not conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                        (user['id'], game_id)).fetchone():
        flash('Сначала купите игру, чтобы оставить отзыв', 'warning')
        conn.close()
        return redirect(url_for('game_detail', game_id=game_id))
    existing = conn.execute('SELECT id FROM reviews WHERE user_id=? AND game_id=?',
                            (user['id'], game_id)).fetchone()
    if existing:
        conn.execute('UPDATE reviews SET rating=?, text=?, created_at=CURRENT_TIMESTAMP WHERE id=?',
                     (rating, text, existing['id']))
        flash('Отзыв обновлён', 'success')
    else:
        conn.execute('INSERT INTO reviews (user_id, game_id, rating, text) VALUES (?,?,?,?)',
                     (user['id'], game_id, rating, text))
        flash('Отзыв добавлен!', 'success')
    avg = conn.execute('SELECT AVG(rating), COUNT(*) FROM reviews WHERE game_id=?',
                       (game_id,)).fetchone()
    if avg[0]:
        conn.execute('UPDATE games SET rating=?, reviews_count=? WHERE id=?',
                     (round(avg[0], 1), avg[1], game_id))
    conn.commit()
    conn.close()
    log_activity(user['id'], 'review', f'Отзыв на игру #{game_id}: {rating}★')
    return redirect(url_for('game_detail', game_id=game_id))

@app.route('/library')
@login_required
def library():
    user = get_current_user()
    sort = request.args.get('sort', 'date')
    conn = get_db()
    order = {'name': 'g.title ASC', 'playtime': 'l.playtime DESC',
             'favorite': 'l.favorite DESC, g.title ASC'}.get(sort, 'l.purchase_date DESC')
    games = conn.execute(f'''SELECT g.*, l.purchase_date, l.playtime, l.favorite
                             FROM library l JOIN games g ON l.game_id = g.id
                             WHERE l.user_id = ? ORDER BY {order}''', (user['id'],)).fetchall()
    conn.close()
    return render_template('library.html', games=games, user=user, sort=sort)

@app.route('/play/<int:game_id>')
@login_required
def play_game(game_id):
    """Simulate playing — add random playtime minutes."""
    user = get_current_user()
    conn = get_db()
    lib = conn.execute('SELECT id, playtime FROM library WHERE user_id=? AND game_id=?',
                       (user['id'], game_id)).fetchone()
    if not lib:
        flash('Игра не в библиотеке', 'error')
        conn.close()
        return redirect(url_for('store'))
    minutes = random.randint(15, 120)
    conn.execute('UPDATE library SET playtime = playtime + ? WHERE id = ?', (minutes, lib['id']))
    game = conn.execute('SELECT title FROM games WHERE id=?', (game_id,)).fetchone()
    conn.commit()
    conn.close()
    log_activity(user['id'], 'play', f'{game["title"]}: +{minutes} мин.')
    flash(f'Вы поиграли в «{game["title"]}» — +{minutes} мин. игрового времени!', 'success')
    return redirect(request.referrer or url_for('library'))

@app.route('/favorite/<int:game_id>')
@login_required
def toggle_favorite(game_id):
    conn = get_db()
    lib = conn.execute('SELECT id, favorite FROM library WHERE user_id=? AND game_id=?',
                       (session['user_id'], game_id)).fetchone()
    if lib:
        new_val = 0 if lib['favorite'] else 1
        conn.execute('UPDATE library SET favorite=? WHERE id=?', (new_val, lib['id']))
        conn.commit()
        flash('Добавлено в избранное' if new_val else 'Убрано из избранного', 'success')
    conn.close()
    return redirect(request.referrer or url_for('library'))

@app.route('/add_funds', methods=['POST'])
@login_required
def add_funds():
    amount = request.form.get('amount', type=float)
    if not amount or amount <= 0 or amount > 10000:
        flash('Сумма должна быть от 1 до 10000 ₽', 'error')
        return redirect(url_for('profile'))
    conn = get_db()
    conn.execute('UPDATE users SET balance = balance + ? WHERE id = ?', (amount, session['user_id']))
    conn.commit()
    conn.close()
    log_activity(session['user_id'], 'funds', f'Пополнение +{amount:.0f} ₽')
    flash(f'Баланс пополнен на {amount:.0f} ₽', 'success')
    return redirect(url_for('profile'))

# ─── Friends ───

@app.route('/friends/add', methods=['POST'])
@login_required
def add_friend():
    username = request.form.get('username', '').strip()
    if not username:
        flash('Введите имя пользователя', 'error')
        return redirect(url_for('profile'))
    conn = get_db()
    target = conn.execute('SELECT id, username FROM users WHERE username = ?', (username,)).fetchone()
    if not target:
        flash('Пользователь не найден', 'error')
        conn.close()
        return redirect(url_for('profile'))
    if target['id'] == session['user_id']:
        flash('Нельзя добавить себя', 'error')
        conn.close()
        return redirect(url_for('profile'))
    existing = conn.execute('''SELECT id FROM friends WHERE
        (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)''',
        (session['user_id'], target['id'], target['id'], session['user_id'])).fetchone()
    if existing:
        flash('Запрос уже отправлен или вы уже друзья', 'info')
        conn.close()
        return redirect(url_for('profile'))
    conn.execute('INSERT INTO friends (user_id, friend_id, status) VALUES (?,?,?)',
                 (session['user_id'], target['id'], 'pending'))
    conn.commit()
    conn.close()
    flash(f'Запрос в друзья отправлен пользователю {username}', 'success')
    return redirect(url_for('profile'))

@app.route('/friends/accept/<int:req_id>')
@login_required
def accept_friend(req_id):
    conn = get_db()
    conn.execute('UPDATE friends SET status=? WHERE id=? AND friend_id=?',
                 ('accepted', req_id, session['user_id']))
    conn.commit()
    conn.close()
    flash('Запрос принят', 'success')
    return redirect(url_for('profile'))

@app.route('/friends/decline/<int:req_id>')
@login_required
def decline_friend(req_id):
    conn = get_db()
    conn.execute('DELETE FROM friends WHERE id=? AND friend_id=?', (req_id, session['user_id']))
    conn.commit()
    conn.close()
    flash('Запрос отклонён', 'info')
    return redirect(url_for('profile'))

# ─── Gifts ───

@app.route('/gift/<int:game_id>', methods=['GET', 'POST'])
@login_required
def gift_game(game_id):
    user = get_current_user()
    conn = get_db()
    game = conn.execute('SELECT * FROM games WHERE id=?', (game_id,)).fetchone()
    if not game:
        flash('Игра не найдена', 'error')
        conn.close()
        return redirect(url_for('store'))
    price = get_final_price(game)
    if request.method == 'POST':
        to_username = request.form.get('username', '').strip()
        message = request.form.get('message', '').strip()
        target = conn.execute('SELECT id FROM users WHERE username=?', (to_username,)).fetchone()
        if not target:
            flash('Пользователь не найден', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        if target['id'] == user['id']:
            flash('Нельзя подарить себе', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        if conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                        (target['id'], game_id)).fetchone():
            flash('У этого пользователя уже есть эта игра', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        if user['balance'] < price:
            flash('Недостаточно средств', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        conn.execute('UPDATE users SET balance = balance - ? WHERE id=?', (price, user['id']))
        conn.execute('INSERT INTO gifts (from_user, to_user, game_id, message) VALUES (?,?,?,?)',
                     (user['id'], target['id'], game_id, message))
        conn.commit()
        conn.close()
        log_activity(user['id'], 'gift', f'Подарок «{game["title"]}» → {to_username}')
        flash(f'Подарок «{game["title"]}» отправлен пользователю {to_username}!', 'success')
        return redirect(url_for('store'))
    conn.close()
    return render_template('gift.html', game=game, user=user, price=price)

@app.route('/gift/accept/<int:gift_id>')
@login_required
def accept_gift(gift_id):
    conn = get_db()
    gift = conn.execute('SELECT * FROM gifts WHERE id=? AND to_user=? AND status=?',
                        (gift_id, session['user_id'], 'pending')).fetchone()
    if gift:
        conn.execute('INSERT OR IGNORE INTO library (user_id, game_id) VALUES (?,?)',
                     (session['user_id'], gift['game_id']))
        conn.execute('UPDATE gifts SET status=? WHERE id=?', ('accepted', gift_id))
        conn.commit()
        flash('Подарок принят! Игра добавлена в библиотеку.', 'success')
    conn.close()
    return redirect(url_for('profile'))

@app.route('/gift/decline/<int:gift_id>')
@login_required
def decline_gift(gift_id):
    conn = get_db()
    gift = conn.execute('SELECT * FROM gifts WHERE id=? AND to_user=? AND status=?',
                        (gift_id, session['user_id'], 'pending')).fetchone()
    if gift:
        # refund sender
        game = conn.execute('SELECT price, discount FROM games WHERE id=?', (gift['game_id'],)).fetchone()
        if game:
            price = get_final_price(game)
            conn.execute('UPDATE users SET balance = balance + ? WHERE id=?', (price, gift['from_user']))
        conn.execute('UPDATE gifts SET status=? WHERE id=?', ('declined', gift_id))
        conn.commit()
        flash('Подарок отклонён, средства возвращены отправителю', 'info')
    conn.close()
    return redirect(url_for('profile'))

@app.route('/user/<username>')
def public_profile(username):
    conn = get_db()
    profile_user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
    if not profile_user:
        flash('Пользователь не найден', 'error')
        conn.close()
        return redirect(url_for('index'))
    library = conn.execute('''SELECT g.* FROM library l JOIN games g ON l.game_id = g.id
                              WHERE l.user_id = ? ORDER BY l.purchase_date DESC LIMIT 12''',
                           (profile_user['id'],)).fetchall()
    reviews = conn.execute('''SELECT r.*, g.title FROM reviews r JOIN games g ON r.game_id = g.id
                              WHERE r.user_id = ? ORDER BY r.created_at DESC LIMIT 5''',
                           (profile_user['id'],)).fetchall()
    conn.close()
    return render_template('public_profile.html', profile_user=profile_user,
                           library=library, reviews=reviews, user=get_current_user())

@app.route('/api/search')
def api_search():
    q = request.args.get('q', '').strip()
    if len(q) < 2:
        return jsonify([])
    conn = get_db()
    games = conn.execute('''SELECT id, title, image_url, price, discount FROM games
                            WHERE title LIKE ? LIMIT 8''', (f'%{q}%',)).fetchall()
    conn.close()
    return jsonify([{
        'id': g['id'], 'title': g['title'], 'image': g['image_url'],
        'price': get_final_price(g), 'discount': g['discount']
    } for g in games])

@app.route('/recent')
def recent_games():
    ids = session.get('recent', [])
    games = []
    if ids:
        conn = get_db()
        placeholders = ','.join('?' * len(ids))
        rows = conn.execute(f'SELECT * FROM games WHERE id IN ({placeholders})', ids).fetchall()
        # preserve order
        by_id = {r['id']: r for r in rows}
        games = [by_id[i] for i in ids if i in by_id]
        conn.close()
    return render_template('recent.html', games=games, user=get_current_user(),
                           get_final_price=get_final_price)


@app.route('/settings')
def settings():
    return render_template('settings.html', user=get_current_user())



@app.context_processor
def inject_globals():
    def _specials():
        try:
            conn = get_db()
            rows = conn.execute("SELECT * FROM games WHERE discount > 0 ORDER BY discount DESC LIMIT 5").fetchall()
            conn.close()
            return rows
        except Exception:
            return []
    return {"specials_global": _specials, "get_final_price": get_final_price}


# Register extra feature routes
try:
    from extra_routes import register_extra_routes
    register_extra_routes(app, {
        'get_db': get_db,
        'get_current_user': get_current_user,
        'login_required': login_required,
        'admin_required': admin_required,
        'get_final_price': get_final_price,
        'unlock_achievement': unlock_achievement,
        'check_achievements': check_achievements,
        'notify': notify,
    })
except Exception as _e:
    print('extra_routes load warning:', _e)


if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
